public class Main {
  public static void Att (String[] args) {
    System.out.println("Hello world!");
  }
